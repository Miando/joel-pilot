from django.apps import AppConfig


class CraigsConfig(AppConfig):
    name = 'craigs'
